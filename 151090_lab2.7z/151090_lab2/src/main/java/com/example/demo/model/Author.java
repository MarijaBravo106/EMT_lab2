package com.example.demo.model;

public class Author {
    private Long id;
    private String name;
    private String surname;
    private Country country;

    public Author(Long id,String name,String surname,Country country){
        this.id=id;
        this.name=name;
        this.surname=surname;
        this.country=country;

    }

    public Author(Long id) {
        this.id = id;
    }

    public Author(String name) {
        this.name = name;
    }

    public Author(Country country) {
        this.country = country;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public Country getCountry() {
        return country;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setCountry(Country country) {
        this.country = country;
    }
}
